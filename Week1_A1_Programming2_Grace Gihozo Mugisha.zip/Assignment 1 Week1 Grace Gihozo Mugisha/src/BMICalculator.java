/**
 * Java program to find BMI of a person.
 */
import java.util.Scanner;

public class BMICalculator {
	
	
	/*
     * calculate BMI if weight/height in kilogram/ meters
     */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		 // Input name of a person
		  System.out.print("Please enter your name: ");
		  String name = sc.next();
		  // Input weight / height of rectangle
	      System.out.println("\nPlease enter weight in kilogram: ");
	      double weight = sc.nextDouble();
	      System.out.println("\nPlease enter height in meters: ");
	      double height = sc.nextDouble();
	     //calculate BMI
	      double BMI = weight / (height * height);
	    //print the result
	      System.out.printf(name +"\nyour body mass index (BMI) is %.2f\n",  BMI );
	     
	      // The range of BMI 
	         if (BMI > 30) {
	        	 System.out.print("\n You are overweight");
				 
				 		
			 }
			 else if (BMI < 15) {
				 System.out.print("\n You are underweight");
				
			}
			 else {
				 System.out.print("\n You are in good condiction");
						
			}
	      
	       System.out.println("\n Everything beautifully");

	}

}
