/*
 * Java program to find perimeter and area of a rectangle.
 */
import java.util.Scanner;

public class Rectangle {

	public static void main(String[] args) {
		
		// Create scanner object
		Scanner sc = new Scanner(System.in);
		
        int width = 0;
        int length = 0;
        int perimeter = 0;
        int area = 0; 
     // Input length and width of rectangle
        System .out .println("Enter width of Rectangle");
        width = sc.nextInt();
        System .out .println("Enter length of Rectangle");
        length = sc.nextInt();
     //  Calculate perimeter  of rectangle
        perimeter = 2*(length + width);
     //  Calculate area of rectangle 
        area = length*width;
     // print result in integer data type
        System.out.println("Perimeter of Rectangle using int data is "+ perimeter);
        System.out.println("Area of Rectangle using int data is "+ area);
     // print result in short data type
        short perimetervalue = (short)perimeter;
        short areavalue = (short)area;
        System.out.println("Perimeter of Rectangle using short data is "+ perimetervalue );
        System.out.println("Area of Rectangle using short data is "+ areavalue);
     // print result in long data type
        long perimetervalue1 = (long)perimeter;
        long areavalue1 = (long)area;
        System.out.println("Perimeter of Rectangle using long data is "+perimetervalue1 );
        System.out.println("Area of Rectangle using long data is "+ areavalue1);
     // print result in double data type
        double perimetervalue2 = (double)perimeter;
        double areavalue2 = (double)area;
        System.out.println("Perimeter of Rectangle using double data is "+perimetervalue2 );
        System.out.println("Area of Rectangle using double data is "+ areavalue2);
        
        
        }
     }
	


