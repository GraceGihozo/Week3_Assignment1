
public class Qn2Difference {

	public static void main(String[] args) {
		// Difference between JDK, JRE, and JVM
		
		
		 System.out.println("The Java Development Kit, also known as the JDK, is a core component of the Java environment that provides all the tools, executables, and binaries needed to compile, debug, and run Java programs "+
		"\n JDK is the superset of JRE since it contains JRE with Java compiler, debugger, and core classes."+ "\n While The JVM is the heart of the Java programming language. When running a Java program, the JVM is responsible for converting bytecode into machine-specific code. \r\n"
				+ " The JVM is customizable and  can be customized using Java options. Example: Allocate minimum and maximum memory to the JVM. The \r\n"
				+ " JVM is called virtual because it provides an interface that is independent of the underlying operating system and machine hardware." + "\n and JRE is a Java Virtual Machine (JVM) implementation. It serves as a platform for Java programs to run on. The JRE is made up of the JVM, Java binaries, and other classes that are required for the successful execution of any program. The Java Runtime Environment (JRE) does not include development tools such as the Java compiler, debugger, or JavaShell.\r\n"
						+ "If you only want to run Java programs, you can install JRE. You do not require a JDK because you will not be developing or compiling Java source code.");
	}

}
